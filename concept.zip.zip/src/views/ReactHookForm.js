import React from "react";
import { useForm } from "react-hook-form";

export default () => {
  const { register, handleSubmit, errors } = useForm();
  const onSubmit = handleSubmit((data) => {
    console.log(`on submit data ${JSON.stringify(data)}`);
  });
  const isRequired = { required: true };

  return (
    <>
      <h2>React Hook Form</h2>
      <form {...{ onSubmit, name: "signin-form" }}>
        <label for="fullname">Full Name: </label>
        <input
          name="fullname"
          placeholder="fullname here"
          // defaultValue="Joe Sm"
          ref={register(isRequired)}
        />
        <br />
        {errors.fullname && <>fullname is required<br /></>}
        
        <label for="password">Password: </label>
        <input name="password" type="password" ref={register} />
        <br />
        
        <label for="gender">Gender: </label>
        <select name="gender" ref={register(isRequired)}>
          {["", "male", "female", "other"].map((val, idx) => {
            return (
              <option key={idx} value={val}>
                {val}
              </option>
            );
          })}
        </select>
        <br />
        {errors.gender && <>gender is required<br /></>}
        
        <label for="checkbox">Checkbox: </label>
        <input name="checkbox" type="checkbox" ref={register(isRequired)} />
        <br />
        {errors.checkbox && <>checkbox is required<br /></>}
        
        <fieldset>
          <legend>Is it True?</legend>
          <input type="radio" id="isTrue" name="radio" ref={register(isRequired)} />
          <label for="isTrue">True</label>
          <br />
          <input type="radio" id="isFalse" name="radio" ref={register(isRequired)} />
          <label for="isFalse">False</label>
          <br />
        </fieldset>
        {errors.radio && <>radio is required<br /></>}

        <button type="submit">Submit</button>
      </form>
    </>
  );
};
