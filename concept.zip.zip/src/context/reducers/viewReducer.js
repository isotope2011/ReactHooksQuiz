import { views } from "../../views";

export const viewMappings = {
  Welcome: views["Welcome"],
  Counter: views["CounterView"],
  Form: views["ReactHookForm"],
  YUPForm: views["ReactYUPForm"],
  ConfigForm: views["ReactConfigForm"],
  HelloWorld: views["HelloWorld"],
};

export const viewStates = {
  currentView: viewMappings["Welcome"],
  view: 'Welcome',
};

export const viewReducer = (state, { type, view }) => {
  switch (type) {
    case "UPDATE_VIEW":
      return {
        ...state,
        view,
        currentView: viewMappings[view]
      };
    case "RESET_VIEW":
        return {
          ...state,
          viewStates
        };
    default:
      return state;
  }
};
