import React from 'react';

export default () => {
    return (
        <h2>Welcome to the world...</h2>
    );
}
