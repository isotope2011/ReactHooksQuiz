import { generalStates } from '../reducers/generalReducer'
import { viewStates } from '../reducers/viewReducer'

export const initialState = {
  generalStates,
  viewStates
};
