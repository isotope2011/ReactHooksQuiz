import { generalActions } from './generalActions'
import { viewActions } from './viewActions'

export const useActions = (state, dispatch) => {
  return {
    generalActions: generalActions({ state, dispatch }),
    viewActions: viewActions({ state, dispatch })
  }
};
