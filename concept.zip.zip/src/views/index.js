import Welcome from './Welcome';
import CounterView from './CounterView';
import ReactHookForm from './ReactHookForm';
import HelloWorld from './HelloWorld';
import ReactYUPForm from './ReactHookYUPForm';
import ReactConfigForm from './ReactHookConfigForm';

const views = {
    CounterView,
    ReactHookForm,
    ReactYUPForm,
    ReactConfigForm,
    HelloWorld,
    Welcome,
};

export { views }
