import React from 'react';

export default () => {
    return (
        <h2>Hello World!!</h2>
    );
}
