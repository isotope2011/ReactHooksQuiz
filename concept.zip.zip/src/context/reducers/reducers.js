import { initialState } from "../state/initialStates";
import { generalReducer } from './generalReducer';
import { viewReducer } from './viewReducer';

const reducer = (state = initialState, action) => {
  return {
    generalStates: generalReducer(state.generalStates,action),
    viewStates: viewReducer(state.viewStates, action),
  }
};

export { initialState, reducer };
