import React, { useCallback, useContext, useEffect } from "react";
import { StoreContext } from "../context/store/storeContext";

export default () => {
  const { state, actions } = useContext(StoreContext);
  const CurrentView = state.viewStates.currentView;

  const onClick = useCallback((event) => {
    actions.viewActions.updateView(event.target.value);
  });

  useEffect(() => {
    console.log(`Main - currentView -> ${state.viewStates.view}`);
  }, [state]);

  return (
    <div>
      {JSON.stringify(state)}
      <div>
        <div>view changes:</div>
        <button {...{ onClick, value: "Welcome" }}>Welcome</button>
        <button {...{ onClick, value: "HelloWorld" }}>Hello World</button>
        <button {...{ onClick, value: "Counter" }}>Counter</button>
      </div>
      <div>
        <div>forms:</div>
        <button {...{ onClick, value: "Form" }}>React Hook Form</button>
        <button {...{ onClick, value: "YUPForm" }}>YUP Form</button>
        <button {...{ onClick, value: "ConfigForm" }}>Config Form</button>
      </div>
      <CurrentView />
    </div>
  );
};
